# Pi 5 Corona HV — N-layout-14-surge

Project checkpoint archived on 2026-10-19. Open `pi5_corona_hv.kicad_pro` in KiCad 10 (validated with 10.0.7). Project-specific symbols, footprints and 3D models are included; install the standard KiCad 10 libraries separately.

The active board includes the LV placement/routing optimization and shortened HV return surge path. Its saved validation reports show zero native DRC/ERC violations, open connections and schematic parity issues. Existing HV insulation/arc qualification remains open. Manufacturing exports in `exports/` include historical artifacts and were not regenerated for N-layout-14-surge; this archive is not a production release.

`ARCHIVE-MANIFEST.json` records every archived project file and its SHA-256. Git metadata, ignored editor/cache/recovery files and unrelated repository files are excluded. Earlier revisions and validation history that belong to the versioned project are included.
